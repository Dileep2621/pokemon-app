import Home from "./components/Home";

export default function page() {
  return (
    <main className="p-10">
      <Home />
    </main>
  );
}

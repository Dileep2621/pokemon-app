import React from "react";

const Loader = () => {
  return <div className="bg-gray-300 h-screen w-full">Loading....</div>;
};

export default Loader;
